import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { safeJsonParse, serializeBotListResponse, serializeBotResponse } from '@/lib/api-helpers'
import { validateBotCreate, sanitizeBotName, sanitizeBotDescription, sanitizeEmoji, sanitizeCustomIcon } from '@/lib/validation'
import { decryptEnvVarsMaskedAsync, decryptEnvVarsAsync, encryptEnvVarsOnSaveAsync } from '@/lib/crypto'

/**
 * P0-1 OPT: Fields to select in list query.
 * Excludes heavy fields that are only needed in detail view:
 *   - projectFiles (up to 5MB per bot)
 *   - code (redundant with codeBlocks)
 *   - envVars (expensive decryption, only needed in detail view)
 */
const BOT_LIST_SELECT: Record<string, true> = {
  id: true,
  name: true,
  description: true,
  emoji: true,
  customIcon: true,
  status: true,
  health: true,
  language: true,
  template: true,
  version: true,
  codeBlocks: true,
  dependencies: true,
  config: true,
  stats: true,
  entryPoint: true,
  lastRunnerStatus: true,
  lastDeployedAt: true,
  // SECURITY FIX: Don't fetch webhookSecret in list query — not needed and prevents accidental leak
  // webhookSecret is still included in config JSON column for backward compat
  createdAt: true,
  updatedAt: true,
}

export async function GET(request: Request) {
  try {
    // P2-API-1 FIX: Add pagination to prevent unbounded list queries
    const { searchParams } = new URL(request.url)
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
    const pageSize = Math.min(10000, Math.max(1, parseInt(searchParams.get('pageSize') || '20', 10)))
    const skip = (page - 1) * pageSize

    const [bots, total] = await Promise.all([
      db.bot.findMany({
        // P0-1 OPT: Only select fields needed for list view, exclude heavy columns
        select: BOT_LIST_SELECT,
        orderBy: { updatedAt: 'desc' },
        skip,
        take: pageSize,
      }),
      db.bot.count(),
    ])

    // P0-1 OPT: Use lightweight list serializer — skips envVar decryption and token validation
    const parsed = bots.map((bot) => serializeBotListResponse(bot))
    return NextResponse.json({
      bots: parsed,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    }, {
      headers: { 'Cache-Control': 'private, no-store, no-cache, must-revalidate' },
    })
  } catch (error) {
    console.error('GET /api/bots error:', error)
    return NextResponse.json({ error: 'Failed to fetch bots' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Parse request body with size limit protection
    let bot: Record<string, unknown>
    try {
      const text = await request.text()
      if (!text.trim()) {
        return NextResponse.json({ error: 'Request body is empty' }, { status: 400 })
      }
      // Reject payloads larger than 5MB (projectFiles from Git/ZIP can be large)
      // BUG FIX: Use Buffer.byteLength() instead of text.length.
      // text.length counts UTF-16 code units, not actual bytes.
      // For multi-byte content (Chinese descriptions, base64 customIcon),
      // the actual size could be 2-3× the character count.
      if (Buffer.byteLength(text, 'utf-8') > 5_000_000) {
        return NextResponse.json({ error: 'Request body too large (max 5MB)' }, { status: 413 })
      }
      bot = JSON.parse(text)
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }

    // Ensure body is a plain object (not array, null, etc.)
    if (typeof bot !== 'object' || bot === null || Array.isArray(bot)) {
      return NextResponse.json({ error: 'Request body must be a JSON object' }, { status: 400 })
    }

    // Full input validation
    const validation = validateBotCreate(bot)
    if (!validation.valid) {
      return NextResponse.json(
        { error: validation.errors[0].message, details: validation.errors },
        { status: 400 }
      )
    }

    const processedEnvVars = await encryptEnvVarsOnSaveAsync((bot.envVars as { key: string; value: string; isEncrypted?: boolean }[]) || [])

    const createData = {
      name: sanitizeBotName(bot.name),
      description: sanitizeBotDescription(bot.description),
      emoji: sanitizeEmoji(bot.emoji),
      customIcon: sanitizeCustomIcon(bot.customIcon),
      status: (bot.status as string) || 'inactive',
      health: (bot.health as string) || 'unknown',
      language: (bot.language as string) || 'typescript',
      template: (bot.template as string) || 'custom',
      version: (bot.version as string) || '1.0.0',
      code: (bot.code as string) || '',
      codeBlocks: JSON.stringify(bot.codeBlocks || []),
      dependencies: JSON.stringify(bot.dependencies || []),
      envVars: JSON.stringify(processedEnvVars),
      config: JSON.stringify(bot.config || {}),
      stats: JSON.stringify(bot.stats || {}),
      projectFiles: JSON.stringify(bot.projectFiles || []),
      entryPoint: (bot.entryPoint as string) || '',
      webhookSecret: ((bot.config as Record<string, unknown>)?.webhookSecret as string) || '',
    }

    const created = await db.bot.create({ data: createData })

    // POST returns full bot data (including envVars for immediate use)
    const serialized = await serializeBotResponse(created, decryptEnvVarsMaskedAsync, decryptEnvVarsAsync)
    return NextResponse.json(serialized)
  } catch (error) {
    console.error('POST /api/bots error:', error)
    return NextResponse.json({ error: 'Failed to create bot' }, { status: 500 })
  }
}
