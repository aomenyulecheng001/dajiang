require('dotenv').config();

require('dotenv').config();
const { Telegraf } = require('telegraf');
const Database = require('better-sqlite3');

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN) {
    console.error('❌ 请设置 BOT_TOKEN');
    process.exit(1);
}
const TIMEZONE = process.env.TIMEZONE || 'Asia/Shanghai';
const CHECK_INTERVAL_SECONDS = 30;
const TG_MSG_MAX_LENGTH = 4096;
const WEEKDAY_MAP = { 1: '一', 2: '二', 3: '三', 4: '四', 5: '五', 6: '六', 7: '日' };
const WEEKDAY_EN_TO_ISO = { 'Sun': 7, 'Mon': 1, 'Tue': 2, 'Wed': 3, 'Thu': 4, 'Fri': 5, 'Sat': 6 };
const PAGE_SIZE = 5;
const RATE_LIMIT_MS = 1000;

const formatters = {
    datetime: new Intl.DateTimeFormat('en-CA', {
        timeZone: TIMEZONE,
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        hour12: false, hourCycle: 'h23'
    }),
    date: new Intl.DateTimeFormat('en-CA', {
        timeZone: TIMEZONE,
        year: 'numeric', month: '2-digit', day: '2-digit'
    }),
    weekday: new Intl.DateTimeFormat('en-US', {
        timeZone: TIMEZONE,
        weekday: 'short'
    })
};

const db = new Database('reminders.sqlite');
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.exec(`
    CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        chat_id INTEGER NOT NULL,
        target_user_id INTEGER,
        target_user_name TEXT,
        rule_type TEXT NOT NULL,
        rule_value TEXT NOT NULL,
        rule_time TEXT,
        repeat_interval_minutes INTEGER DEFAULT 0,
        last_remind_time INTEGER,
        last_completed_date TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
    );
`);
const columns = db.pragma('table_info(reminders)').map(c => c.name);
if (!columns.includes('target_user_name')) db.exec(`ALTER TABLE reminders ADD COLUMN target_user_name TEXT`);
if (!columns.includes('rule_time')) db.exec(`ALTER TABLE reminders ADD COLUMN rule_time TEXT`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_chat_id ON reminders(chat_id)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_name_chat ON reminders(name, chat_id)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_last_completed ON reminders(last_completed_date)`);
db.exec(`CREATE INDEX IF NOT EXISTS idx_active_check ON reminders(rule_type, last_completed_date)`);
console.log('✅ 数据库初始化完成');

const stmts = {
    addReminder: db.prepare(`
        INSERT INTO reminders (name, chat_id, target_user_id, target_user_name, rule_type, rule_value, rule_time, repeat_interval_minutes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `),
    deleteById: db.prepare('DELETE FROM reminders WHERE id = ?'),
    getById: db.prepare('SELECT * FROM reminders WHERE id = ?'),
    getByNameAndChat: db.prepare('SELECT * FROM reminders WHERE name = ? AND chat_id = ?'),
    getActiveReminders: db.prepare(`
        SELECT * FROM reminders
        WHERE (rule_type != 'absolute' OR rule_value >= ?)
          AND (last_completed_date IS NULL OR last_completed_date != ?)
    `),
    getByChatIdPaged: db.prepare('SELECT * FROM reminders WHERE chat_id = ? ORDER BY id LIMIT ? OFFSET ?'),
    countByChatId: db.prepare('SELECT COUNT(*) as count FROM reminders WHERE chat_id = ?'),
    checkNameExists: db.prepare('SELECT id FROM reminders WHERE name = ? AND chat_id = ?'),
    updateLastRemindTime: db.prepare('UPDATE reminders SET last_remind_time = ? WHERE id = ?'),
    markCompletedToday: db.prepare('UPDATE reminders SET last_completed_date = ? WHERE id = ?'),
    updateRule: db.prepare(`
        UPDATE reminders SET rule_type = ?, rule_value = ?, rule_time = ?, repeat_interval_minutes = ? WHERE id = ?
    `),
    countActiveReminders: db.prepare(`
        SELECT COUNT(*) as count FROM reminders
        WHERE (rule_type != 'absolute' OR rule_value >= ?)
          AND (last_completed_date IS NULL OR last_completed_date != ?)
    `),
    resetReminderState: db.prepare(`
        UPDATE reminders SET last_completed_date = NULL, last_remind_time = NULL WHERE id = ?
    `),
};

const rateLimitMap = new Map();
const snoozeMap = new Map();
const userDisplayNameCache = new Map();
const USER_CACHE_TTL = 3600000;

let isShuttingDown = false;
let checkTimer = null;
let cleanupTimer = null;

function parseTargetUserNameField(value) {
    if (!value) return [];
    try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) return parsed;
    } catch {}
    return [value];
}

function parseTargetUsersFromText(text) {
    if (!text || !text.startsWith('@')) return [];
    return text.match(/@[a-zA-Z0-9_]+/g) || [];
}

function getNow() {
    const now = new Date();
    const parts = formatters.datetime.formatToParts(now);
    let year, month, day, hour, minute, second;
    for (const p of parts) {
        if (p.type === 'year') year = parseInt(p.value);
        if (p.type === 'month') month = parseInt(p.value);
        if (p.type === 'day') day = parseInt(p.value);
        if (p.type === 'hour') hour = parseInt(p.value);
        if (p.type === 'minute') minute = parseInt(p.value);
        if (p.type === 'second') second = parseInt(p.value);
    }
    const todayStr = formatters.date.format(now);
    const weekdayStr = formatters.weekday.format(now);
    const weekday = WEEKDAY_EN_TO_ISO[weekdayStr] || 1;
    return { year, month, day, hour, minute, second, timestamp: Math.floor(now.getTime() / 1000), todayStr, weekday };
}

function escapeHtml(str) {
    return str.replace(/[&<>"']/g, m => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;',
        '"': '&quot;', "'": '&#39;'
    })[m]);
}

function getRuleDescription(ruleType, ruleValue, ruleTime) {
    let desc = '';
    switch (ruleType) {
        case 'absolute': desc = `日期：${ruleValue}`; break;
        case 'monthly': desc = `每月 ${ruleValue} 号`; break;
        case 'yearly': desc = `每年 ${ruleValue}`; break;
        case 'daily': desc = `每天 ${ruleValue}`; break;
        case 'weekly': desc = `每周${WEEKDAY_MAP[ruleValue] || ruleValue}`; break;
        default: desc = `${ruleType} ${ruleValue}`;
    }
    if (ruleTime) desc += ` ${ruleTime}`;
    return desc;
}

function getNextTriggerTime(ruleType, ruleValue, ruleTime) {
    const { year, month, day, hour, minute, weekday } = getNow();
    const timeStr = ruleTime || (ruleType === 'daily' ? ruleValue : null);
    const [th, tm] = timeStr ? timeStr.split(':').map(Number) : [9, 0];

    if (ruleType === 'absolute') {
        return `${ruleValue}${ruleTime ? ' ' + ruleTime : ''}`;
    }
    if (ruleType === 'daily') {
        if (hour < th || (hour === th && minute < tm)) {
            return `今天 ${ruleValue}`;
        }
        return `明天 ${ruleValue}`;
    }
    if (ruleType === 'weekly') {
        const targetWeekday = parseInt(ruleValue);
        let daysAhead;
        if (weekday === targetWeekday && (hour < th || (hour === th && minute < tm))) {
            daysAhead = 0;
        } else {
            daysAhead = ((targetWeekday - weekday + 7) % 7) || 7;
        }
        const target = new Date(Date.now() + daysAhead * 86400000);
        const targetStr = formatters.date.format(target);
        return `${targetStr} 星期${WEEKDAY_MAP[ruleValue] || ruleValue}${ruleTime ? ' ' + ruleTime : ''}`;
    }
    if (ruleType === 'monthly') {
        const targetDay = parseInt(ruleValue);
        let targetMonth = month;
        let targetYear = year;
        if (day > targetDay || (day === targetDay && (hour > th || (hour === th && minute >= tm)))) {
            targetMonth++;
            if (targetMonth > 12) { targetMonth = 1; targetYear++; }
        }
        return `${targetYear}-${String(targetMonth).padStart(2, '0')}-${String(targetDay).padStart(2, '0')}${ruleTime ? ' ' + ruleTime : ''}`;
    }
    if (ruleType === 'yearly') {
        const [targetMonth, targetDay] = ruleValue.split('-').map(Number);
        let targetYear = year;
        if (month > targetMonth || (month === targetMonth && (day > targetDay || (day === targetDay && (hour > th || (hour === th && minute >= tm)))))) {
            targetYear++;
        }
        return `${targetYear}-${ruleValue}${ruleTime ? ' ' + ruleTime : ''}`;
    }
    return '未知';
}

function addReminder(name, chatId, targetUserId, targetUserName, ruleType, ruleValue, ruleTime, repeatIntervalMinutes) {
    try {
        const result = stmts.addReminder.run(name, chatId, targetUserId, targetUserName, ruleType, ruleValue, ruleTime, repeatIntervalMinutes);
        return result.lastInsertRowid;
    } catch (err) {
        console.error('添加提醒失败:', err.message);
        throw err;
    }
}

function deleteReminderById(id) {
    try {
        stmts.deleteById.run(id);
    } catch (err) {
        console.error('删除提醒失败:', err.message);
        throw err;
    }
}

function updateReminderRule(id, ruleType, ruleValue, ruleTime, repeatIntervalMinutes) {
    try {
        stmts.updateRule.run(ruleType, ruleValue, ruleTime, repeatIntervalMinutes, id);
    } catch (err) {
        console.error('更新规则失败:', err.message);
        throw err;
    }
}

function getActiveReminders(todayStr) {
    try {
        return stmts.getActiveReminders.all(todayStr, todayStr);
    } catch (err) {
        console.error('查询提醒失败:', err.message);
        return [];
    }
}

function updateLastRemindTime(id, timestamp) {
    try {
        stmts.updateLastRemindTime.run(timestamp, id);
    } catch (err) {
        console.error('更新提醒时间失败:', err.message);
    }
}

function markCompletedToday(id, today) {
    try {
        stmts.markCompletedToday.run(today, id);
    } catch (err) {
        console.error('标记完成失败:', err.message);
    }
}

function isSnoozed(reminderId, now) {
    const snoozeUntil = snoozeMap.get(reminderId);
    if (!snoozeUntil) return false;
    if (now.timestamp >= snoozeUntil) {
        snoozeMap.delete(reminderId);
        return false;
    }
    return true;
}

function shouldRemind(reminder, now) {
    if (isSnoozed(reminder.id, now)) return false;

    const { month, day, hour, minute, timestamp, todayStr, weekday } = now;
    if (reminder.last_completed_date === todayStr) return false;

    let matched = false;
    if (reminder.rule_type === 'absolute') {
        if (todayStr === reminder.rule_value) matched = true;
    } else if (reminder.rule_type === 'monthly') {
        if (day === parseInt(reminder.rule_value)) matched = true;
    } else if (reminder.rule_type === 'yearly') {
        const [targetMonth, targetDay] = reminder.rule_value.split('-').map(Number);
        if (month === targetMonth && day === targetDay) matched = true;
    } else if (reminder.rule_type === 'daily') {
        const [targetHour, targetMinute] = reminder.rule_value.split(':').map(Number);
        if (hour > targetHour || (hour === targetHour && minute >= targetMinute)) matched = true;
    } else if (reminder.rule_type === 'weekly') {
        const w = parseInt(reminder.rule_value);
        if (w >= 1 && w <= 7 && weekday === w) matched = true;
    }

    if (!matched) return false;

    if (reminder.rule_time) {
        const [targetHour, targetMinute] = reminder.rule_time.split(':').map(Number);
        if (hour < targetHour || (hour === targetHour && minute < targetMinute)) return false;
    }

    if (reminder.repeat_interval_minutes === 0) {
        if (reminder.last_remind_time) {
            const lastDateStr = formatters.date.format(new Date(reminder.last_remind_time * 1000));
            if (lastDateStr === todayStr) return false;
        }
        return true;
    } else {
        if (!reminder.last_remind_time) return true;
        const secondsSince = timestamp - reminder.last_remind_time;
        return secondsSince >= reminder.repeat_interval_minutes * 60;
    }
}

async function getUserDisplayName(bot, userId) {
    const now = Date.now();
    const cached = userDisplayNameCache.get(userId);
    if (cached && now - cached.ts < USER_CACHE_TTL) return cached.name;
    try {
        const chat = await bot.telegram.getChat(userId);
        let name;
        if (chat.username) name = `@${chat.username}`;
        else if (chat.first_name) name = chat.first_name;
        else name = `用户${userId}`;
        userDisplayNameCache.set(userId, { name, ts: now });
        return name;
    } catch {
        const name = `用户${userId}`;
        userDisplayNameCache.set(userId, { name, ts: now });
        return name;
    }
}

function buildReminderKeyboard(reminder) {
    const buttons = [[
        { text: '✅ 知道了', callback_data: `done:${reminder.id}` }
    ]];
    if (reminder.repeat_interval_minutes > 0) {
        buttons[0].push({ text: `🕐 延后${reminder.repeat_interval_minutes}分钟`, callback_data: `snooze:${reminder.id}:${reminder.repeat_interval_minutes}` });
    }
    buttons[0].push({ text: '🗑️ 删除', callback_data: `del_confirm:${reminder.id}` });
    return { inline_keyboard: buttons };
}

async function sendReminder(bot, reminder, now) {
    let message = `🔔 <b>提醒：${escapeHtml(reminder.name)}</b>\n`;
    message += `${getRuleDescription(reminder.rule_type, reminder.rule_value, reminder.rule_time)}\n`;
    if (reminder.repeat_interval_minutes > 0) {
        message += `🔁 每 ${reminder.repeat_interval_minutes} 分钟重复一次（仅今天）\n`;
    } else {
        message += `🔁 仅提醒一次\n`;
    }

    const targetUsers = parseTargetUserNameField(reminder.target_user_name);
    if (targetUsers.length > 0) {
        message += `\n请及时处理：\n${targetUsers.map(u => escapeHtml(u)).join(' ')}`;
    } else if (reminder.target_user_id) {
        const name = await getUserDisplayName(bot, reminder.target_user_id);
        message += `\n请及时处理：\n<a href="tg://user?id=${reminder.target_user_id}">${escapeHtml(name)}</a>`;
    }

    message += `\n\n📌 按钮说明：`;
    message += `\n<code>✅ 知道了 — 标记今日已完成，今天不再提醒</code>`;
    if (reminder.repeat_interval_minutes > 0) {
        message += `\n<code>🕐 延后${reminder.repeat_interval_minutes}分钟 — 暂停提醒，${reminder.repeat_interval_minutes}分钟后再次通知</code>`;
    }
    message += `\n<code>🗑️ 删除 — 永久删除此事件</code>`;

    const keyboard = buildReminderKeyboard(reminder);
    let sendSuccess = false;
    try {
        await bot.telegram.sendMessage(reminder.chat_id, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: keyboard
        });
        console.log(`[提醒] ${reminder.name} -> chat ${reminder.chat_id}`);
        sendSuccess = true;
    } catch (err) {
        console.error(`发送失败: ${err.description || err.message}`);
    }

    if (sendSuccess) {
        updateLastRemindTime(reminder.id, now.timestamp);
    }

    if (reminder.rule_type === 'absolute' && reminder.repeat_interval_minutes === 0 && sendSuccess) {
        deleteReminderById(reminder.id);
        snoozeMap.delete(reminder.id);
        console.log(`[自动删除] ${reminder.name} 绝对到期一次性提醒`);
    }
}

async function checkAndRemind(bot) {
    if (isShuttingDown) return;
    const now = getNow();
    const reminders = getActiveReminders(now.todayStr);
    console.log(`[检查] ${now.todayStr} ${String(now.hour).padStart(2, '0')}:${String(now.minute).padStart(2, '0')} | 活跃事件: ${reminders.length}`);

    const chatGroups = new Map();
    for (const r of reminders) {
        if (shouldRemind(r, now)) {
            if (isShuttingDown) break;
            console.log(`[触发] #${r.id} "${r.name}" rule=${r.rule_type} repeat=${r.repeat_interval_minutes} rule_time=${r.rule_time || '无'}`);
            if (!chatGroups.has(r.chat_id)) chatGroups.set(r.chat_id, []);
            chatGroups.get(r.chat_id).push(r);
        }
    }

    const chatEntries = [...chatGroups.values()];
    for (const group of chatEntries) {
        if (isShuttingDown) break;
        for (const r of group) {
            if (isShuttingDown) break;
            await sendReminder(bot, r, now);
        }
        if (group.length > 0 && !isShuttingDown) await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

function getMentionedUserInfo(ctx) {
    const result = { targetUserId: null, targetUserName: null };
    if (!ctx.message.entities) return result;
    for (const e of ctx.message.entities) {
        if (e.type === 'text_mention' && !result.targetUserId) {
            result.targetUserId = e.user.id;
            if (e.user.username) result.targetUserName = `@${e.user.username}`;
            else if (e.user.first_name) result.targetUserName = e.user.first_name;
        } else if (e.type === 'mention' && !result.targetUserName) {
            const text = ctx.message.text;
            result.targetUserName = text.substring(e.offset, e.offset + e.length);
        }
    }
    return result;
}

function validateRuleValue(ruleType, ruleValue) {
    if (ruleType === 'monthly') {
        const day = parseInt(ruleValue);
        if (day < 1 || day > 31) return '每月日期必须在 1-31 之间';
    } else if (ruleType === 'weekly') {
        const w = parseInt(ruleValue);
        if (w < 1 || w > 7) return '每周日期必须在 1-7 之间';
    } else if (ruleType === 'yearly') {
        const [m, d] = ruleValue.split('-').map(Number);
        if (m < 1 || m > 12) return '月份必须在 1-12 之间';
        if (d < 1 || d > 31) return '日期必须在 1-31 之间';
    }
    return null;
}

function parseRule(rule) {
    let ruleType = null, ruleValue = null, ruleTime = null;

    if (rule.match(/^\d{4}-\d{2}-\d{2}(@\d{2}:\d{2})?$/)) {
        ruleType = 'absolute';
        const [date, time] = rule.split('@');
        ruleValue = date;
        ruleTime = time || null;
    } else if (rule.match(/^M-\d{1,2}(@\d{2}:\d{2})?$/)) {
        ruleType = 'monthly';
        const [dayPart, time] = rule.substring(2).split('@');
        ruleValue = dayPart;
        ruleTime = time || null;
    } else if (rule.match(/^\d{2}-\d{2}(@\d{2}:\d{2})?$/)) {
        ruleType = 'yearly';
        const [datePart, time] = rule.split('@');
        ruleValue = datePart;
        ruleTime = time || null;
    } else if (rule.match(/^\d{2}:\d{2}$/)) {
        ruleType = 'daily';
        ruleValue = rule;
        ruleTime = null;
    } else if (rule.match(/^W-[1-7](@\d{2}:\d{2})?$/)) {
        ruleType = 'weekly';
        const [dayPart, time] = rule.substring(2).split('@');
        ruleValue = dayPart;
        ruleTime = time || null;
    }

    if (!ruleType) return null;

    const validationError = validateRuleValue(ruleType, ruleValue);
    if (validationError) return { error: validationError };

    return { ruleType, ruleValue, ruleTime };
}

function parseRepeatParams(parts, startIdx) {
    let repeatMinutes = 0;

    for (let i = startIdx; i < parts.length; i++) {
        const token = parts[i];
        if (token.toLowerCase() === 'every' && i + 1 < parts.length && parts[i + 1].match(/^\d+m$/i)) {
            const numMatch = parts[i + 1].match(/^(\d+)m$/i);
            if (numMatch) {
                repeatMinutes = parseInt(numMatch[1]);
                if (repeatMinutes <= 0) return { repeatMinutes: 0, repeatIndex: -1 };
            }
            return { repeatMinutes, repeatIndex: i };
        }
        if (token.match(/^every\d+m$/i)) {
            const match = token.match(/^every(\d+)m$/i);
            if (match) {
                repeatMinutes = parseInt(match[1]);
                if (repeatMinutes <= 0) return { repeatMinutes: 0, repeatIndex: -1 };
            }
            return { repeatMinutes, repeatIndex: i };
        }
    }
    return { repeatMinutes: 0, repeatIndex: -1 };
}

function parseReminderParts(parts) {
    let frontUserName = null;
    let idx = 0;

    if (parts[0] && parts[0].startsWith('@')) {
        frontUserName = parts[0];
        idx = 1;
    }
    if (parts.length < idx + 2) return null;

    const name = parts[idx];
    const rule = parts[idx + 1];

    let tailUserName = null;
    if (parts.length > idx + 2) {
        const lastPart = parts[parts.length - 1];
        if (lastPart.startsWith('@') && !lastPart.match(/^@\d{2}:\d{2}$/)) {
            tailUserName = lastPart;
            parts = parts.slice(0, -1);
        }
    }

    const { repeatMinutes } = parseRepeatParams(parts, idx + 2);

    let allUserNames = [];
    if (frontUserName) {
        const users = parseTargetUsersFromText(frontUserName);
        allUserNames.push(...users);
    }
    if (tailUserName) {
        const users = parseTargetUsersFromText(tailUserName);
        allUserNames.push(...users);
    }

    const parsedRule = parseRule(rule);
    if (!parsedRule) return null;
    if (parsedRule.error) return { error: parsedRule.error };

    const targetUserName = allUserNames.length > 0 ? JSON.stringify([...new Set(allUserNames)]) : null;

    return { name, targetUserName, ...parsedRule, repeatMinutes };
}

function parseRemindCommand(text, mentionedUserInfo) {
    let parts = text.split(/\s+/);
    if (parts[0] !== '/remind' && parts[0] !== '/remind@d1j_ai2_bot') return null;
    parts = parts.slice(1);

    const parsed = parseReminderParts(parts);
    if (!parsed) return null;
    if (parsed.error) return { error: parsed.error };

    let targetUserId = mentionedUserInfo.targetUserId;

    if (!parsed.targetUserName && mentionedUserInfo.targetUserName) {
        parsed.targetUserName = JSON.stringify([mentionedUserInfo.targetUserName]);
    }

    return { ...parsed, targetUserId };
}

function parseEditCommand(text) {
    let parts = text.split(/\s+/);
    if (parts[0] !== '/edit' && parts[0] !== '/edit@d1j_ai2_bot') return null;
    parts = parts.slice(1);

    if (parts.length < 2) return null;

    const nameOrId = parts[0];
    const rule = parts[1];

    const parsedRule = parseRule(rule);
    if (!parsedRule) return null;
    if (parsedRule.error) return { error: parsedRule.error };

    const { repeatMinutes } = parseRepeatParams(parts, 2);

    return { nameOrId, ...parsedRule, repeatMinutes };
}

function parseBatchLine(line) {
    const parts = line.trim().split(/\s+/);
    const parsed = parseReminderParts(parts);
    if (!parsed) return null;
    if (parsed.error) return { error: parsed.error };
    return { ...parsed, targetUserId: null };
}

async function sendLongMessage(ctx, message, parseMode = null) {
    const opts = parseMode ? { parse_mode: parseMode } : {};
    if (message.length <= TG_MSG_MAX_LENGTH) {
        await ctx.reply(message, opts);
        return;
    }
    const lines = message.split('\n');
    let chunk = '';
    for (const line of lines) {
        if (line.length > TG_MSG_MAX_LENGTH) {
            if (chunk.trim()) {
                await ctx.reply(chunk.trim(), opts);
                chunk = '';
            }
            for (let i = 0; i < line.length; i += TG_MSG_MAX_LENGTH) {
                await ctx.reply(line.slice(i, i + TG_MSG_MAX_LENGTH), opts);
            }
            continue;
        }
        if (chunk.length + line.length + 1 > TG_MSG_MAX_LENGTH) {
            await ctx.reply(chunk.trim(), opts);
            chunk = line + '\n';
        } else {
            chunk += line + '\n';
        }
    }
    if (chunk.trim()) {
        await ctx.reply(chunk.trim(), opts);
    }
}

async function sendListPage(ctx, page, isCallback = false) {
    const chatId = isCallback ? ctx.callbackQuery.message.chat.id : ctx.chat.id;
    const countResult = stmts.countByChatId.get(chatId);
    const total = countResult.count;

    if (total === 0) {
        if (isCallback) {
            try { await ctx.editMessageText('📭 当前没有提醒事件。'); } catch {}
        } else {
            await ctx.reply('📭 当前没有提醒事件。');
        }
        return;
    }

    const totalPages = Math.ceil(total / PAGE_SIZE);
    const safePage = Math.min(page, totalPages - 1);
    const offset = safePage * PAGE_SIZE;
    const reminders = stmts.getByChatIdPaged.all(chatId, PAGE_SIZE, offset);
    const now = getNow();

    let msg = `📋 <b>提醒列表</b>（${safePage + 1}/${totalPages} 页，共 ${total} 个）\n\n`;
    for (const r of reminders) {
        let item = `🔸 <b>#${r.id} ${escapeHtml(r.name)}</b>\n`;
        item += `   ${getRuleDescription(r.rule_type, r.rule_value, r.rule_time)}\n`;
        if (r.repeat_interval_minutes > 0) item += `   重复：每 ${r.repeat_interval_minutes} 分钟（仅触发当天）\n`;
        else item += `   重复：一次\n`;
        if (r.last_completed_date === now.todayStr) item += `   ⚠️ 今日已完成，不会再提醒\n`;
        const targetUsers = parseTargetUserNameField(r.target_user_name);
        if (targetUsers.length > 0) item += `   提醒对象：${targetUsers.map(u => escapeHtml(u)).join(' ')}\n`;
        else if (r.target_user_id) item += `   提醒对象：用户ID ${r.target_user_id}\n`;
        item += '\n';
        msg += item;
    }

    const buttons = [];
    for (const r of reminders) {
        buttons.push([{ text: `🗑️ 删除 #${r.id} ${r.name}`, callback_data: `del_confirm_list:${safePage}:${r.id}` }]);
    }

    const navRow = [];
    if (safePage > 0) navRow.push({ text: '◀ 上一页', callback_data: `list:${safePage - 1}` });
    if (safePage < totalPages - 1) navRow.push({ text: '下一页 ▶', callback_data: `list:${safePage + 1}` });
    if (navRow.length) buttons.push(navRow);

    const replyMarkup = { inline_keyboard: buttons };

    if (isCallback) {
        try {
            await ctx.editMessageText(msg, { parse_mode: 'HTML', reply_markup: replyMarkup });
        } catch {
            await ctx.answerCbQuery('列表已更新');
        }
    } else {
        await ctx.reply(msg, { parse_mode: 'HTML', reply_markup: replyMarkup });
    }
}

function findReminder(arg, chatId) {
    if (arg.startsWith('#')) {
        const id = parseInt(arg.slice(1));
        if (isNaN(id)) return null;
        const r = stmts.getById.get(id);
        return (r && r.chat_id === chatId) ? r : null;
    }
    return stmts.getByNameAndChat.get(arg, chatId) || null;
}

function setupCommands(bot) {
    bot.command('remind', async (ctx) => {
        const chatId = ctx.chat.id;
        const mentionedInfo = getMentionedUserInfo(ctx);
        const parsed = parseRemindCommand(ctx.message.text, mentionedInfo);
        if (!parsed) {
            await ctx.reply(`❌ 格式错误。
用法：/remind 名称 时间规则 [every Nm] [@用户]

时间规则：
· 2026-07-01 或 2026-07-01@09:00（绝对到期）
· M-5 或 M-5@09:00（每月5号）
· 12-25 或 12-25@08:00（每年12月25日）
· 20:00（每天20:00）
· W-3 或 W-3@14:30（每周三）

重复：every Nm 或 everyNm（如 every 30m 或 every30m）
@用户：放在末尾，提醒时会 @该用户
多个用户用 - 分隔：@用户1-@用户2-@用户3
注意：名称不能包含空格

示例：
/remind 还房贷 2026-07-01
/remind 吃药 20:00 every 30m @d1j88
/remind 交房租 M-28@09:00 every 60m @d1j88
/remind 周报 W-5@17:00 @张三
/remind 开会 09:00 every 1m @张三-@李四-@王五

💡 批量创建请使用 /batch 命令`);
            return;
        }

        if (parsed.error) {
            await ctx.reply(`❌ ${parsed.error}`);
            return;
        }

        const existing = stmts.checkNameExists.get(parsed.name, chatId);
        if (existing) {
            await ctx.reply(`❌ 事件「${parsed.name}」已存在，请换一个名称或先 /del 删除旧事件`);
            return;
        }

        let newId;
        try {
            newId = addReminder(
                parsed.name, chatId, parsed.targetUserId, parsed.targetUserName,
                parsed.ruleType, parsed.ruleValue, parsed.ruleTime, parsed.repeatMinutes
            );
        } catch {
            await ctx.reply('❌ 添加失败，请稍后重试');
            return;
        }

        const nextTrigger = getNextTriggerTime(parsed.ruleType, parsed.ruleValue, parsed.ruleTime);
        let msg = `✅ 已添加事件「${parsed.name}」（#${newId}）\n`;
        msg += `规则：${getRuleDescription(parsed.ruleType, parsed.ruleValue, parsed.ruleTime)}\n`;
        msg += `⏰ 下次触发：${nextTrigger}\n`;
        if (parsed.repeatMinutes > 0) {
            msg += `每 ${parsed.repeatMinutes} 分钟重复一次（仅触发当天）`;
        } else {
            msg += `仅提醒一次（绝对到期）或每天/月/年一次（循环）`;
        }
        if (parsed.targetUserName) {
            const users = parseTargetUserNameField(parsed.targetUserName);
            msg += `\n提醒对象：${users.join(' ')}`;
        }

        await ctx.reply(msg);
    });

    bot.command('edit', async (ctx) => {
        const chatId = ctx.chat.id;
        const parsed = parseEditCommand(ctx.message.text);
        if (!parsed) {
            await ctx.reply(`❌ 格式错误。
用法：/edit 事件名称 新时间规则 [every Nm]

示例：
/edit 吃药 21:00
/edit 周报 W-4@16:00 every 60m
/edit 还房贷 2026-08-01@09:00

时间规则与 /remind 相同，只修改规则和时间，不改变名称和提醒对象`);
            return;
        }

        if (parsed.error) {
            await ctx.reply(`❌ ${parsed.error}`);
            return;
        }

        const reminder = findReminder(parsed.nameOrId, chatId);
        if (!reminder) {
            await ctx.reply(`❌ 未找到事件「${parsed.nameOrId}」`);
            return;
        }

        try {
            updateReminderRule(reminder.id, parsed.ruleType, parsed.ruleValue, parsed.ruleTime, parsed.repeatMinutes);
        } catch {
            await ctx.reply('❌ 更新失败，请稍后重试');
            return;
        }

        const nextTrigger = getNextTriggerTime(parsed.ruleType, parsed.ruleValue, parsed.ruleTime);
        let msg = `✏️ 已更新事件「${reminder.name}」（#${reminder.id}）\n`;
        msg += `旧规则：${getRuleDescription(reminder.rule_type, reminder.rule_value, reminder.rule_time)}\n`;
        msg += `新规则：${getRuleDescription(parsed.ruleType, parsed.ruleValue, parsed.ruleTime)}\n`;
        msg += `⏰ 下次触发：${nextTrigger}\n`;
        if (parsed.repeatMinutes > 0) {
            msg += `每 ${parsed.repeatMinutes} 分钟重复一次（仅触发当天）`;
        } else {
            msg += `仅提醒一次（绝对到期）或每天/月/年一次（循环）`;
        }

        stmts.resetReminderState.run(reminder.id);
        msg += `\n⚠️ 状态已重置，将按新规则重新计算触发`;

        await ctx.reply(msg);
    });

    bot.command('batch', async (ctx) => {
        const chatId = ctx.chat.id;
        const text = ctx.message.text;
        const lines = text.split('\n');

        if (lines.length < 2) {
            await ctx.reply(`❌ 格式错误。
用法：/batch（换行后每行一个事件）
每行格式：名称 时间规则 [every Nm] [@用户]
多个用户用 - 分隔：@用户1-@用户2-@用户3

示例：
/batch
吃药 21:00 @da1j888
周报 W-4@16:00 every 60m @da1j888
还房贷 2026-08-01@09:00 @da1j888
开会 09:00 every 1m @da1j888-@zhuzhuxia_0976

时间规则与 /remind 相同`);
            return;
        }

        const dataLines = lines.slice(1).filter(l => l.trim().length > 0);

        if (dataLines.length === 0) {
            await ctx.reply('❌ 没有检测到事件数据，请在 /batch 下方每行写一个事件');
            return;
        }

        const results = [];

        for (const line of dataLines) {
            const parsed = parseBatchLine(line);

            if (!parsed) {
                results.push({ line, success: false, error: '格式错误' });
                continue;
            }

            if (parsed.error) {
                results.push({ line, success: false, error: parsed.error });
                continue;
            }

            const existing = stmts.checkNameExists.get(parsed.name, chatId);
            if (existing) {
                results.push({ line, success: false, error: `事件「${parsed.name}」已存在` });
                continue;
            }

            try {
                const newId = addReminder(
                    parsed.name, chatId, parsed.targetUserId, parsed.targetUserName,
                    parsed.ruleType, parsed.ruleValue, parsed.ruleTime, parsed.repeatMinutes
                );
                const nextTrigger = getNextTriggerTime(parsed.ruleType, parsed.ruleValue, parsed.ruleTime);
                results.push({
                    line, success: true, name: parsed.name, id: newId,
                    desc: getRuleDescription(parsed.ruleType, parsed.ruleValue, parsed.ruleTime),
                    nextTrigger,
                    repeatMinutes: parsed.repeatMinutes,
                    targetUserName: parsed.targetUserName
                });
            } catch {
                results.push({ line, success: false, error: '添加失败' });
            }
        }

        const successCount = results.filter(r => r.success).length;
        const failCount = results.filter(r => !r.success).length;

        let msg = `📋 <b>批量创建结果</b>（${successCount} 成功 / ${failCount} 失败）\n\n`;

        for (const r of results) {
            if (r.success) {
                msg += `✅ <b>${escapeHtml(r.name)}</b>（#${r.id}）\n`;
                msg += `   ${r.desc} | 下次触发：${r.nextTrigger}\n`;
                if (r.repeatMinutes > 0) msg += `   每 ${r.repeatMinutes} 分钟重复\n`;
                if (r.targetUserName) {
                    const users = parseTargetUserNameField(r.targetUserName);
                    msg += `   提醒对象：${users.join(' ')}\n`;
                }
            } else {
                msg += `❌ ${escapeHtml(r.line.trim())}\n   原因：${r.error}\n`;
            }
        }

        await sendLongMessage(ctx, msg, 'HTML');
    });

    bot.command('done', async (ctx) => {
        const arg = ctx.message.text.split(/\s+/).slice(1).join(' ').trim();
        if (!arg) return ctx.reply('用法：/done 事件名称 或 /done #ID');
        const reminder = findReminder(arg, ctx.chat.id);
        if (!reminder) {
            await ctx.reply(`❌ 未找到事件「${arg}」`);
            return;
        }
        if (reminder.rule_type === 'absolute' && reminder.repeat_interval_minutes === 0) {
            deleteReminderById(reminder.id);
            snoozeMap.delete(reminder.id);
            await ctx.reply(`🗑️ 已删除一次性事件「${reminder.name}」`);
        } else {
            const now = getNow();
            markCompletedToday(reminder.id, now.todayStr);
            snoozeMap.delete(reminder.id);
            await ctx.reply(`✅ 已标记「${reminder.name}」已知晓，今天不再提醒。下个周期仍会正常提醒。`);
        }
    });

    bot.command('del', async (ctx) => {
        const arg = ctx.message.text.split(/\s+/).slice(1).join(' ').trim();
        if (!arg) return ctx.reply('用法：/del 事件名称 或 /del #ID');
        const reminder = findReminder(arg, ctx.chat.id);
        if (!reminder) {
            await ctx.reply(`❌ 未找到事件「${arg}」`);
            return;
        }
        deleteReminderById(reminder.id);
        snoozeMap.delete(reminder.id);
        await ctx.reply(`🗑️ 已永久删除事件「${reminder.name}」`);
    });

    bot.command('list', async (ctx) => {
        await sendListPage(ctx, 0);
    });

    bot.command('debug', async (ctx) => {
        const arg = ctx.message.text.split(/\s+/).slice(1).join(' ').trim();
        if (!arg) return ctx.reply('用法：/debug 事件名称 或 /debug #ID');
        const reminder = findReminder(arg, ctx.chat.id);
        if (!reminder) {
            await ctx.reply(`❌ 未找到事件「${arg}」`);
            return;
        }

        const now = getNow();
        let msg = `🔍 <b>调试：${escapeHtml(reminder.name)}</b> (#${reminder.id})\n\n`;
        msg += `📅 当前时间：${now.todayStr} ${String(now.hour).padStart(2, '0')}:${String(now.minute).padStart(2, '0')} 时区：${TIMEZONE}\n\n`;
        msg += `📋 规则：${reminder.rule_type} ${reminder.rule_value}`;
        if (reminder.rule_time) msg += ` 时间：${reminder.rule_time}`;
        msg += `\n`;

        let dateMatch = false;
        if (reminder.rule_type === 'absolute') {
            dateMatch = now.todayStr === reminder.rule_value;
            msg += `📅 日期匹配：${now.todayStr} === ${reminder.rule_value} → ${dateMatch ? '✅' : '❌'}\n`;
        } else if (reminder.rule_type === 'monthly') {
            dateMatch = now.day === parseInt(reminder.rule_value);
            msg += `📅 日期匹配：今天${now.day}号 === ${reminder.rule_value}号 → ${dateMatch ? '✅' : '❌'}\n`;
        } else if (reminder.rule_type === 'yearly') {
            const [m, d] = reminder.rule_value.split('-').map(Number);
            dateMatch = now.month === m && now.day === d;
            msg += `📅 日期匹配：${now.month}-${now.day} === ${reminder.rule_value} → ${dateMatch ? '✅' : '❌'}\n`;
        } else if (reminder.rule_type === 'daily') {
            const [h, m] = reminder.rule_value.split(':').map(Number);
            dateMatch = now.hour > h || (now.hour === h && now.minute >= m);
            msg += `⏰ 时间匹配：${String(now.hour).padStart(2, '0')}:${String(now.minute).padStart(2, '0')} >= ${reminder.rule_value} → ${dateMatch ? '✅' : '❌'}\n`;
        } else if (reminder.rule_type === 'weekly') {
            dateMatch = now.weekday === parseInt(reminder.rule_value);
            msg += `📅 星期匹配：星期${WEEKDAY_MAP[now.weekday] || now.weekday} === ${WEEKDAY_MAP[reminder.rule_value] || reminder.rule_value} → ${dateMatch ? '✅' : '❌'}\n`;
        }

        if (dateMatch && reminder.rule_time) {
            const [h, m] = reminder.rule_time.split(':').map(Number);
            const timeReached = now.hour > h || (now.hour === h && now.minute >= m);
            msg += `⏰ rule_time：${String(now.hour).padStart(2, '0')}:${String(now.minute).padStart(2, '0')} vs ${reminder.rule_time} → ${timeReached ? '已到 ✅' : '未到 ⏳'}\n`;
        }

        if (isSnoozed(reminder.id, now)) {
            const snoozeUntil = snoozeMap.get(reminder.id);
            const remaining = Math.ceil((snoozeUntil - now.timestamp) / 60);
            msg += `🕐 已延后：还剩 ${remaining} 分钟 → 不触发 ❌\n`;
        }

        if (reminder.last_completed_date === now.todayStr) {
            msg += `⚠️ 今日已完成 → 不会触发 ❌\n`;
        }

        if (reminder.repeat_interval_minutes > 0) {
            msg += `🔁 重复间隔：${reminder.repeat_interval_minutes} 分钟\n`;
            if (reminder.last_remind_time) {
                const elapsed = Math.floor((now.timestamp - reminder.last_remind_time) / 60);
                msg += `⏱️ 距上次提醒：${elapsed} 分钟（需 ${reminder.repeat_interval_minutes} 分钟）→ ${elapsed >= reminder.repeat_interval_minutes ? '可触发 ✅' : '未到 ⏳'}\n`;
            } else {
                msg += `⏱️ 尚未提醒过 → 可触发 ✅\n`;
            }
        } else {
            if (reminder.last_remind_time) {
                const lastDateStr = formatters.date.format(new Date(reminder.last_remind_time * 1000));
                msg += `🔁 无重复，上次提醒日期：${lastDateStr} → ${lastDateStr === now.todayStr ? '今天已提醒 ❌' : '今天未提醒 ✅'}\n`;
            } else {
                msg += `🔁 无重复，尚未提醒过 → 可触发 ✅\n`;
            }
        }

        const should = shouldRemind(reminder, now);
        msg += `\n🎯 最终结果：${should ? '触发 ✅' : '不触发 ❌'}`;

        await ctx.reply(msg, { parse_mode: 'HTML' });
    });

    bot.command('help', async (ctx) => {
        await ctx.reply(`📌 <b>命令说明</b>

/remind 名称 时间规则 [every Nm] [@用户]
   添加提醒（名称不能包含空格）
   时间规则：
    · 2026-07-01 或 2026-07-01@09:00（绝对到期）
    · M-5 或 M-5@09:00（每月5号）
    · 12-25 或 12-25@08:00（每年12月25日）
    · 20:00（每天20:00）
    · W-3 或 W-3@14:30（每周三，1=周一...7=周日）
   @HH:MM 可为月/年/周规则指定提醒时间
   重复（可选）：
    · every Nm：在触发当天每N分钟重复一次
   @用户（可选）：
    · 放在末尾，提醒时会 @该用户
    · 多个用户用 - 分隔：@用户1-@用户2-@用户3

/batch（换行后每行一个事件）
   批量创建提醒，每行格式：名称 时间规则 [every Nm] [@用户]
   示例：
   /batch
   吃药 21:00 @da1j888
   周报 W-4@16:00 every 60m @da1j888
   开会 09:00 every 1m @da1j888-@zhuzhuxia_0976

/edit 事件名称 新时间规则 [every Nm]
   修改已有事件的时间规则
   不改变名称和提醒对象
   示例：/edit 吃药 21:00  /edit 周报 W-4@16:00

/done 名称 或 /done #ID
   对于绝对到期一次性事件：删除事件
   对于循环事件：标记今日已完成，今天不再提醒

/del 名称 或 /del #ID
   永久删除事件（无论类型）

/list
   查看当前群组所有事件（分页展示）

/debug 名称 或 /debug #ID
   调试指定事件的触发判断过程

/time
   查看当前时间和活跃事件数

/help
   显示本帮助

💡 提醒消息下方附带操作按钮：
   ✅ 知道了 — 标记今日已完成，今天不再提醒
   🕐 延后 — 暂停提醒，间隔时间后再次通知（仅重复事件）
   🗑️ 删除 — 永久删除此事件

示例：
/remind 还房贷 2026-07-01
/remind 吃药 20:00 every 30m @d1j88
/remind 周报 W-5@17:00 @张三
/remind 开会 09:00 every 1m @张三-@李四-@王五
/edit 吃药 21:00

批量示例：
/batch
吃药 21:00 @da1j888
周报 W-4@16:00 every 60m @da1j888
还房贷 2026-08-01@09:00 @da1j888
开会 09:00 every 1m @da1j888-@zhuzhuxia_0976`, { parse_mode: 'HTML' });
    });

    bot.command('start', async (ctx) => {
        await ctx.reply('👋 你好！我是提醒机器人，发送 /help 查看使用说明');
    });

    bot.command('time', async (ctx) => {
        const now = getNow();
        const countResult = stmts.countActiveReminders.get(now.todayStr, now.todayStr);
        await ctx.reply(
            `🕐 当前时间（${TIMEZONE}）\n` +
            `📅 ${now.todayStr} 星期${WEEKDAY_MAP[now.weekday] || now.weekday}\n` +
            `⏰ ${String(now.hour).padStart(2, '0')}:${String(now.minute).padStart(2, '0')}:${String(now.second).padStart(2, '0')}\n\n` +
            `活跃事件数：${countResult.count}`
        );
    });
}

function setupCallbacks(bot) {
    bot.action(/^done:(\d+)$/, async (ctx) => {
        const id = parseInt(ctx.match[1]);
        const reminder = stmts.getById.get(id);
        if (!reminder) return ctx.answerCbQuery('❌ 事件已不存在');

        if (reminder.rule_type === 'absolute' && reminder.repeat_interval_minutes === 0) {
            deleteReminderById(id);
            snoozeMap.delete(id);
            try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
            await ctx.answerCbQuery('🗑️ 已删除一次性事件');
        } else {
            const now = getNow();
            markCompletedToday(id, now.todayStr);
            snoozeMap.delete(id);
            try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
            await ctx.answerCbQuery('✅ 已知晓，今天不再提醒，下个周期仍会提醒');
        }
    });

    bot.action(/^del_confirm_list:(\d+):(\d+)$/, async (ctx) => {
        const page = parseInt(ctx.match[1]);
        const id = parseInt(ctx.match[2]);
        const reminder = stmts.getById.get(id);
        if (!reminder) return ctx.answerCbQuery('❌ 事件已不存在');

        try {
            await ctx.editMessageReplyMarkup({
                inline_keyboard: [[
                    { text: '⚠️ 确认删除', callback_data: `del_exec_list:${page}:${id}` },
                    { text: '取消', callback_data: `del_cancel_list:${page}:${id}` }
                ]]
            });
        } catch {}
        await ctx.answerCbQuery();
    });

    bot.action(/^del_exec_list:(\d+):(\d+)$/, async (ctx) => {
        const page = parseInt(ctx.match[1]);
        const id = parseInt(ctx.match[2]);
        deleteReminderById(id);
        snoozeMap.delete(id);
        await sendListPage(ctx, page, true);
        await ctx.answerCbQuery('🗑️ 已永久删除');
    });

    bot.action(/^del_cancel_list:(\d+):(\d+)$/, async (ctx) => {
        const page = parseInt(ctx.match[1]);
        await sendListPage(ctx, page, true);
        await ctx.answerCbQuery('已取消');
    });

    bot.action(/^del_confirm:(\d+)$/, async (ctx) => {
        const id = parseInt(ctx.match[1]);
        const reminder = stmts.getById.get(id);
        if (!reminder) return ctx.answerCbQuery('❌ 事件已不存在');

        try {
            await ctx.editMessageReplyMarkup({
                inline_keyboard: [[
                    { text: '⚠️ 确认删除', callback_data: `del_exec:${id}` },
                    { text: '取消', callback_data: `del_cancel:${id}` }
                ]]
            });
        } catch {}
        await ctx.answerCbQuery();
    });

    bot.action(/^del_exec:(\d+)$/, async (ctx) => {
        const id = parseInt(ctx.match[1]);
        deleteReminderById(id);
        snoozeMap.delete(id);
        try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
        await ctx.answerCbQuery('🗑️ 已永久删除');
    });

    bot.action(/^del_cancel:(\d+)$/, async (ctx) => {
        const id = parseInt(ctx.match[1]);
        const reminder = stmts.getById.get(id);
        if (!reminder) return ctx.answerCbQuery('❌ 事件已不存在');

        try {
            await ctx.editMessageReplyMarkup(buildReminderKeyboard(reminder));
        } catch {}
        await ctx.answerCbQuery('已取消');
    });

    bot.action(/^snooze:(\d+):(\d+)$/, async (ctx) => {
        const id = parseInt(ctx.match[1]);
        const minutes = parseInt(ctx.match[2]);
        const reminder = stmts.getById.get(id);
        if (!reminder) {
            try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
            return ctx.answerCbQuery('❌ 事件已不存在');
        }
        const now = getNow();
        snoozeMap.set(id, now.timestamp + minutes * 60);
        try { await ctx.editMessageReplyMarkup({ inline_keyboard: [] }); } catch {}
        await ctx.answerCbQuery(`🕐 已延后 ${minutes} 分钟`);
    });

    bot.action(/^list:(\d+)$/, async (ctx) => {
        const page = parseInt(ctx.match[1]);
        await sendListPage(ctx, page, true);
        await ctx.answerCbQuery();
    });
}

async function scheduleCheck(bot) {
    if (isShuttingDown) return;
    try {
        await checkAndRemind(bot);
    } catch (err) {
        console.error('检查出错:', err);
    }
    if (isShuttingDown) return;
    const now = Date.now();
    const interval = CHECK_INTERVAL_SECONDS * 1000;
    const nextTick = Math.ceil(now / interval) * interval;
    checkTimer = setTimeout(() => scheduleCheck(bot), Math.max(nextTick - now, 1000));
}

async function gracefulShutdown(bot, signal) {
    if (isShuttingDown) return;
    isShuttingDown = true;
    console.log(`\n🛑 收到 ${signal}，开始优雅关闭...`);

    if (checkTimer) {
        clearTimeout(checkTimer);
        checkTimer = null;
        console.log('   ⏱️ 检查定时器已取消');
    }

    if (cleanupTimer) {
        clearInterval(cleanupTimer);
        cleanupTimer = null;
        console.log('   🧹 清理定时器已取消');
    }

    try {
        console.log('   🔄 正在停止 Telegram 轮询...');
        bot.stop(signal);
        console.log('   ✅ Telegram 轮询已停止');
    } catch (err) {
        console.error('   ⚠️ 停止 Telegram 时出错:', err.message);
    }

    try {
        db.close();
        console.log('   ✅ 数据库连接已关闭');
    } catch (err) {
        console.error('   ⚠️ 关闭数据库时出错:', err.message);
    }

    console.log('👋 优雅关闭完成');
    setTimeout(() => process.exit(0), 500);
}

async function main() {
    const bot = new Telegraf(BOT_TOKEN);

    bot.catch((err, ctx) => {
        console.error(`Bot error for ${ctx?.updateType}:`, err);
    });

    bot.use(async (ctx, next) => {
        if (isShuttingDown) return;
        if (ctx.callbackQuery) return await next();

        const userId = ctx.from?.id;
        if (userId) {
            const now = Date.now();
            const last = rateLimitMap.get(userId) || 0;
            if (now - last < RATE_LIMIT_MS) return;
            rateLimitMap.set(userId, now);
        }
        try {
            await next();
        } catch (err) {
            console.error('命令执行出错:', err);
            await ctx.reply('❌ 内部错误，请稍后重试').catch(() => {});
        }
    });

    cleanupTimer = setInterval(() => {
        const now = Date.now();
        for (const [key, value] of rateLimitMap) {
            if (now - value > 60000) rateLimitMap.delete(key);
        }
        for (const [key, value] of userDisplayNameCache) {
            if (now - value.ts > USER_CACHE_TTL) userDisplayNameCache.delete(key);
        }
        const nowTs = Math.floor(now / 1000);
        for (const [key, value] of snoozeMap) {
            if (nowTs >= value) snoozeMap.delete(key);
        }
    }, 60000);

    setupCommands(bot);
    setupCallbacks(bot);

    try {
        await bot.launch();
        console.log('✅ Telegram 轮询已启动');
    } catch (err) {
        console.error('❌ 启动 Telegram 失败:', err.message);
        db.close();
        process.exit(1);
    }

    scheduleCheck(bot);
    console.log(`✅ 定时检查已启动（每 ${CHECK_INTERVAL_SECONDS} 秒），时区：${TIMEZONE}`);
    console.log('🚀 机器人已就绪');

    process.once('SIGINT', () => gracefulShutdown(bot, 'SIGINT'));
    process.once('SIGTERM', () => gracefulShutdown(bot, 'SIGTERM'));
}
main().catch(err => {
    console.error('❌ 启动失败:', err);
    try { db.close(); } catch {}
    process.exit(1);
});
